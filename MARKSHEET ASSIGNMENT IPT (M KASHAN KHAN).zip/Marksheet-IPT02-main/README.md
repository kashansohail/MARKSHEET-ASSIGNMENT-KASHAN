# Student Marksheet-IPT Lab Task 02

![SS-1](https://user-images.githubusercontent.com/47315358/99153863-38eadf80-26cd-11eb-8493-9ad66eb85da2.png)
![SS-2](https://user-images.githubusercontent.com/47315358/99153864-3ab4a300-26cd-11eb-8810-7f6ece030f57.png)
